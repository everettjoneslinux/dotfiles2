#! /bin/bash
picom
