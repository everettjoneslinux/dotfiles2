#! /bin/bash
feh --bg-fill /home/everett/wallpaper.jpg
