#! /bin/bash
ytfzf -t -T kitty
