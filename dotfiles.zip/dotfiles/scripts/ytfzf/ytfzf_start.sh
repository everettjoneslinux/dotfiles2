#! /bin/bash
kitty -e /home/everett/scripts/ytfzf/ytfzf.sh
