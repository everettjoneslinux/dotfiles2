#! /bin/sh

kitty -e ranger
