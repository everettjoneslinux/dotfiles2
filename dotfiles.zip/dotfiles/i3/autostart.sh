#! /bin/bash
sxhkd &
sh ~/.screenlayout/screen.sh &
picom -b &
sh /home/everett/scripts/wallpaper.sh 

